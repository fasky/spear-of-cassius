//enemy class for creating enemies
class Enemy extends PIXI.Sprite{
    constructor(life,type,x,y,enemyHurt,countdown,isAlive,visible){
        if(type == 1){
            super(PIXI.loader.resources["images/Sachiel.png"].texture);
            this.anchor.y = 1;
        }
        else if(type == 2){
            super(PIXI.loader.resources["images/Ramiel.png"].texture);
        }
        else if(type == 3){
            super(PIXI.loader.resources["images/ZeruelStand.png"].texture);
        }
        this.x = x;
        this.y = y;
        this.life = life;
        this.type = type;
        this.vx = 0;
        this.vy = 0;
        this.enemyHurt = enemyHurt;
        this.countdown = countdown;
        this.isAlive = isAlive;
        this.visible = visible;
        this.anchor.x = 1;
    }
}

//projectile/ moving object class - for enemy ranged attacks and rubble in scroller segment
class Projectile extends PIXI.Sprite{
    constructor(x,y,speed,texture){
        super(texture);
        this.x = x;
        this.y = y;
        this.fwd = {x:-1,y:0};
        this.speed = speed;
        this.isAlive = true;
        this.type = "projectile";
    }
    
    //move the projectile left to the player
    move(dt=1/60){
        this.x += this.fwd.x * this.speed * dt;
        this.y += this.fwd.y * this.speed * dt;
    }
}