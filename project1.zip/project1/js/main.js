"use strict";
//////////////////////////////////////////////////////////////////////////////
//create application
let app = new PIXI.Application(960,544);
document.body.appendChild(app.view);

// pre-load the images
PIXI.loader.add(["images/Stage1.png","images/Stage2.png","images/PlayerStand.png","images/PlayerPunch.png","images/Sachiel.png","images/SachielPunch.png","images/Ramiel.png","images/RamielAttack.png", "images/RamielShot.png","images/Crouch.png", "images/Obstacle.png", "images/Obstacle2.png","images/Stage3.png","images/Stage4.png","images/Stage1Card.png","images/Stage2Card.png","images/Stage3Card.png","images/Intro.png","images/Outro.png","images/Finale.png","images/StartCard.png","images/EndCard.png","images/FailureCard.png","images/cross.png","images/PlayerWalk2.png","images/PlayerWalk1.png","images/BardielWalk2.png","images/BardielWalk1.png","images/PlayerJump.png","images/BardielJump.png","images/FinaleAnim.png","images/ZeruelAttack.png","images/ZeruelShot.png","images/ZeruelJump.png","images/ZeruelWalk.png","images/ZeruelFire.png","images/ZeruelStand.png"]).on("progress").load(setup);

// aliases
let stage;

// game variables
let startScene, gameOverScene;
//stages, labels, enemies, buttons
let stage1,stage2,scoreLabel,gameOverScoreLabel,lifeLabel,endLabel,enemy1,enemy2,enemy3, player,menuButton,lifeLabelE,comboLabel,scrollLabel,startScore;
//sounds
let buttonSound,deathSound,shootSound,hitSound,jumpSound,musicSound,ramielSound,slideSound,walkSound;

//scrolling backgrounds
let scroller1,scroller2,scroller3;

//variables and arrays
let score = 0;
let life = 100;
let levelNum = 0;
let paused = true;
let jumping = false; //player is jumping?
let attacking = false; //player is attacking?
let countdown = 0;
let hurt = false;
let enemy = [];
let projectiles = [];
let scrollers = []; //for scrolling section
var finaleAnim;
let mult = 0;
let multCountdown = 0;
let enemyMoveCountdown = 0;
let determine = 0;
let enemyJump = false;
let randomly = false;
let cardCountdown = 0;
let sideScroll = false;
let scrollTimePassed = 0;
let animationFrame = 0;
let deathSingle = 0;
let walkAnimFrame = 0;
let bardielWalkAnimFrame = 0;
let ending;

//local storage - high score
let highScore = localStorage.getItem("kmf-7094-highScore");

//arrow keys - movement and attack (right)
let left = keyboard(65);
let up = keyboard(87);
let right = keyboard(68);
let down = keyboard(83);
let rightAttack = keyboard(39);

//background
let background = PIXI.Sprite.fromImage("images/StartCard.png");

/////////////////////////////////////////////////////////////////////////////////////
//Functions
//start game - set values, place player, stage 1 start, set enemies
function startGame(){
    
    //play button sound, signal title card to change background
    buttonSound.play();
    startScene.visible = false;
    gameOverScene.visible = false;
    cardCountdown = 360;
    
    //set up scrolling backgrounds for later
    scroller1 = PIXI.Sprite.fromImage("images/Stage4.png");
    scroller2 = PIXI.Sprite.fromImage("images/Stage4.png");
    scroller3 = PIXI.Sprite.fromImage("images/Stage4.png");
    scroller1.x = 0;
    scroller2.x = 960;
    scroller3.x = 1920;
    stage1.addChild(scroller1);
    stage1.addChild(scroller2);
    stage1.addChild(scroller3);
    scrollers.push(scroller1);
    scrollers.push(scroller2);
    scrollers.push(scroller3);
    for(let s of scrollers){
        s.visible = false;
    }
    
    //set player
    player = PIXI.Sprite.fromImage('images/PlayerStand.png');
    player.anchor.y = 1;
    player.vx = 0;
    player.vy = 0;
    player.x = 10;
    player.y= 540;
    stage1.addChild(player);

    //set level num, score, and player life
    levelNum = 1;
    score = 0;
    life = 100;
    
    //set enemies
    enemy1 = new Enemy(120,1,850,540,false,0,true,true);
    enemy2 = new Enemy(100,2,850,180,false,0,false,false);
    enemy3 = new Enemy(100,3,850,180,false,0,false,false);
    enemy.push(enemy1);
    decreaseELifeBy(enemy1,0);
    enemy.push(enemy2);
    enemy.push(enemy3);
    stage1.addChild(enemy1);
    stage1.addChild(enemy2);
    stage1.addChild(enemy3);

    //make score and life visible
    increaseScoreBy(0);
    decreaseLifeBy(0);
}

//increase score
function increaseScoreBy(value){
    score += value;
    scoreLabel.text = `Score ${score}`;
}

//take life away
function decreaseLifeBy(value){
    life -= value;
    life = parseInt(life);
    lifeLabel.text = `Armor ${life}%`;
}

//take enemy life away
function decreaseELifeBy(enemy,value){
    enemy.life -= value;
    enemy.life = parseInt(enemy.life);
    lifeLabelE.text = `Enemy ${enemy.life}%`;
}

//load sprite sheet for ending
function loadSpriteSheet(){
    let spriteSheet = PIXI.BaseTexture.fromImage("images/FinaleAnim.png");
    let width = 960;
    let height = 544;
    let numFrames = 11;
    let textures = [];
    for(let i=0; i<numFrames;i++){
        let frame = new PIXI.Texture(spriteSheet, new PIXI.Rectangle(0, i * height, width, height));
        textures.push(frame);
    }
    return textures;
}

//keyboard function - helps with movement - source of help: https://github.com/kittykatattack/learningPixi#keyboard
function keyboard(keyCode){
    let key = {};
    key.code = keyCode;
    key.isDown = false;
    key.isUp = true;
    key.press = undefined;
    key.release = undefined;
    
    //downHandler
    key.downHandler = function(event) {
    if (event.keyCode === key.code) {
      if (key.isUp && key.press) key.press();
      key.isDown = true;
      key.isUp = false;
    }
    event.preventDefault();
    };

    //The upHandler
    key.upHandler = function(event) {
    if (event.keyCode === key.code) {
      if (key.isDown && key.release) key.release();
      key.isDown = false;
      key.isUp = true;
    }
    event.preventDefault();
    };

    //Attach event listeners
    window.addEventListener(
    "keydown", key.downHandler.bind(key), false
    );
    window.addEventListener(
    "keyup", key.upHandler.bind(key), false
    );
    return key;
}

//movement keyboard controls
function move(){
    //keys movement
	right.press = function(){
        if(stage2.visible == false){
            player.vx = 5;
            if(player.texture != PIXI.loader.resources["images/Crouch.png"].texture && player.texture != PIXI.loader.resources["images/PlayerJump.png"].texture){
                player.texture = PIXI.loader.resources["images/PlayerWalk1.png"].texture;
            }
            app.ticker.add(walkAnim);
        }
    };
    
    right.release = function() {
        if (!left.isDown) {
            player.vx = 0;
            app.ticker.remove(walkAnim);
            if(player.texture != PIXI.loader.resources["images/Crouch.png"].texture && player.texture != PIXI.loader.resources["images/PlayerJump.png"].texture){
                player.texture = PIXI.loader.resources["images/PlayerStand.png"].texture;
            }
        }
    };
    
    left.press = function(){
        if(stage2.visible == false){
            if(player.texture != PIXI.loader.resources["images/Crouch.png"].texture && player.texture != PIXI.loader.resources["images/PlayerJump.png"].texture){
                player.texture = PIXI.loader.resources["images/PlayerWalk1.png"].texture;
            }
            player.vx = -3;
            app.ticker.add(walkAnim);
        }
    };
    
    left.release = function() {
        if (!right.isDown) {
            player.vx = 0;
            app.ticker.remove(walkAnim);
            if(player.texture != PIXI.loader.resources["images/Crouch.png"].texture && player.texture != PIXI.loader.resources["images/PlayerJump.png"].texture){
                player.texture = PIXI.loader.resources["images/PlayerStand.png"].texture;
            }
        }
    };
    
    up.press = function(){
        if(jumping == false)
        {
            jumpSound.play();
            player.texture = PIXI.loader.resources["images/PlayerJump.png"].texture;
            player.vy = -27;
            jumping = true;
        }
    };
    
    //handle jumping
    if(jumping == true){
        if(player.vy < 26){
            player.vy++;
        }
        else{
            jumping = false;
            player.vy = 0;
            player.texture = PIXI.loader.resources["images/PlayerStand.png"].texture;
        }
    };
    
    //crouch
    down.press = function(){
        player.texture = PIXI.loader.resources["images/Crouch.png"].texture;
    };
        
    //stop crouching
    down.release = function(){
        player.texture = PIXI.loader.resources["images/PlayerStand.png"].texture;
    };
}

//simple walk animator for player
function walkAnim(){ //instead of spritesheet
    walkAnimFrame++;
    if(walkAnimFrame == 15){
        walkAnimFrame = 0;
        if(player.texture == PIXI.loader.resources["images/Crouch.png"].texture && player.texture == PIXI.loader.resources["images/PlayerJump.png"].texture){
            return;
        }
        //play walk sound if not crouching or jumping
        walkSound.play();
        walkSound.volume(.25);
        if(player.texture == PIXI.loader.resources["images/PlayerWalk1.png"].texture || player.texture == PIXI.loader.resources["images/PlayerStand.png"].texture){
            player.texture = PIXI.loader.resources["images/PlayerWalk2.png"].texture;
        }
        else if(player.texture == PIXI.loader.resources["images/PlayerWalk2.png"].texture){
            player.texture = PIXI.loader.resources["images/PlayerWalk1.png"].texture;
        }
    }
}

//simple walk animate for bardiel
function bardielWalk(){
    bardielWalkAnimFrame++;
    if(bardielWalkAnimFrame == 15){
        bardielWalkAnimFrame = 0;
        if(enemy1.texture == PIXI.loader.resources["images/BardielWalk1.png"].texture || enemy1.texture == PIXI.loader.resources["images/Sachiel.png"].texture){
            enemy1.texture = PIXI.loader.resources["images/BardielWalk2.png"].texture;
        }
        else if(enemy1.texture == PIXI.loader.resources["images/BardielWalk2.png"].texture){
            enemy1.texture = PIXI.loader.resources["images/BardielWalk1.png"].texture;
        }
    }
}

//check off screen player or enemies
function checkBounds(){
    for(let e of enemy){
        if(e.x > 1000){
            e.x = 1000;
        }
        if(e.x < 100){
            e.x = 100;
        }
    }
    if(player.x > 1000){
        player.x = 1000;
    }
    if(player.x < -10)
    {
        player.x = -10;
    }
}

//title card helper - show diff images based on countdown time, start next level once done
function titleCards(){
    //1st level
    if(levelNum == 1 && cardCountdown >= 130){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/Intro.png'].texture;
    }
    
    if(levelNum == 1 && cardCountdown <= 130 && cardCountdown > 0){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/Stage1Card.png'].texture;
        if(cardCountdown == 1){
            musicSound.play(); 
            musicSound.volume(.25);
        }
    }
    
    if(levelNum == 1 && cardCountdown <= 0){
        background.texture = PIXI.loader.resources['images/Stage1.png'].texture;
        paused = false;
        stage1.visible = true;
    }
    
    //2nd level
    if(levelNum == 2 && cardCountdown >= 140){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/cross.png'].texture;
        paused = true;
        stage1.visible = false;
    }
    else if(levelNum == 2 && cardCountdown >= 0){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/Stage2Card.png'].texture;
        if(cardCountdown == 1){
            ramielSound.play();
            ramielSound.volume(.3);
        }
    }
    
    if(levelNum == 2 && cardCountdown <= 0){
        background.texture = PIXI.loader.resources['images/Stage2.png'].texture;
        paused = false;
        stage1.visible = true;
    }
    
    //3rd level
    if(levelNum == 3 && cardCountdown >= 140){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/cross.png'].texture;
        paused = true;
        stage1.visible = false;
    }
    else if(levelNum == 3 && cardCountdown >= 0){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/Stage3Card.png'].texture;
    }
    
    if(levelNum == 3 && cardCountdown <= 0){
        background.texture = PIXI.loader.resources['images/Stage3.png'].texture;
        paused = false;
        stage1.visible = true;
    }
    
    //4th level
    if(levelNum == 4 && cardCountdown >= 140){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/cross.png'].texture;
        paused = true;
        stage1.visible = false;
    }
    else if(levelNum == 4 && cardCountdown >= 0){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/Outro.png'].texture;
        if(cardCountdown == 1){
            app.ticker.add(walkAnim);
            stage2.addChild(lifeLabel);
            stage2.addChild(scoreLabel);
        }
    }
    
    if(levelNum == 4 && cardCountdown <= 0){
        background.texture = PIXI.loader.resources['images/Stage4.png'].texture;
        paused = false;
        stage1.visible = true;
        scrollLabel.x = 765;
        scrollLabel.y = 5;
    }
    
    //finale
    if(levelNum == 5 && cardCountdown >= 0){
        cardCountdown--;
        background.texture = PIXI.loader.resources['images/Finale.png'].texture;
        paused = true;
        stage1.visible = false;
        stage2.visible = false;
        if(cardCountdown == -1){
            app.ticker.add(endingAnimation);
        }
    }
    
}

//handle ending scene - play the ending
function endingAnimation(){

    if(animationFrame == 0){
        ending = new PIXI.extras.AnimatedSprite(finaleAnim);
        ending.x = 0;
        ending.y = 0;
        ending.animationSpeed = 1/60;
        ending.onComplete = e =>stage.removeChild(ending);
        ending.loop = false;
        stage.addChild(ending);
        ending.play();
    }
    
    animationFrame++;

    if(animationFrame > 330){
        background.texture = PIXI.loader.resources['images/EndCard.png'].texture;
        menuButton.style.fill = 0x000000;
        gameOverScene.visible = true;
    }
}

//attack control - right arrow
function attacks(){
    //attacks
    rightAttack.press = function(){
        if(attacking == false && hurt == false){
            player.texture = PIXI.loader.resources["images/PlayerPunch.png"].texture;
            attacking = true;
            countdown = 15;
            jumpSound.play();
        }
    };
    
    if(attacking == true){
        countdown--;
        if(countdown == 0){
            attacking = false;
            player.texture = PIXI.loader.resources["images/PlayerStand.png"].texture;
        }
    }
}

//enemy move determination - check type, randomly decide what to do
function enemyMove(enemy,dt){
    enemyMoveCountdown--;
    determine = 0;
    determine = Math.floor(Math.random() * 100) + 1;
    
    if(enemy.x < player.x){
        enemy.vx = 20;
    }
    
    //check is first type is in air.
    if(enemy.type == 1 && enemyJump == true){
        //handle jumping
        if(enemy.vy < 25){
            enemy.vy++;
        }
        else{
            enemyJump = false;
            enemy.vx = 0;
            enemy.vy = 0;
        }   
    }
    
    //check third type
    if(enemy.type == 3 && enemyJump == true){
        if(enemy.vy < 20){
            enemy.vy++;
        }
        else{
            enemyJump = false;
            enemy.vx = 0;
            enemy.vy = 0;
            enemy.y = 180;
        }   
    }
    
    //determine move if time
    if(enemyMoveCountdown < 1 && enemy.enemyHurt == false){
        
        randomly = false;
        
        //reset velocities
        enemy.vx = 0;
        enemy.vy = 0;
        
        enemyMoveCountdown = 60; //have time between moves
        
        //check type, apply moves
        //first enemy
        if(enemy.type == 1){
            
            enemy.texture = PIXI.loader.resources["images/Sachiel.png"].texture;
            
            if((enemy.x - player.x) < 300){
                enemy.texture = PIXI.loader.resources["images/SachielPunch.png"].texture;
                app.ticker.remove(bardielWalk);
            }
            else {
                if(determine > 66){
                    enemy.vx = -8;
                    enemy.vy = -25;
                    enemyJump = true;
                    jumpSound.play();
                    enemy.texture = PIXI.loader.resources["images/BardielJump.png"].texture;
                    app.ticker.remove(bardielWalk);
                }
                else{
                    app.ticker.remove(bardielWalk);
                    app.ticker.add(bardielWalk);
                    enemy.vx = -2; 
                }
            }
        }

        //second enemy
        else if(enemy.type == 2){
            if((enemy.x - player.x) < 200){
                enemy.vx = 1;
                enemy.texture = PIXI.loader.resources["images/RamielAttack.png"].texture;
                let b = new Projectile(enemy.x - 200,enemy.y + 80,1200, PIXI.loader.resources["images/RamielShot.png"].texture);
                projectiles.push(b);
                stage1.addChild(b);
                shootSound.play();
                shootSound.volume(0.2);
            }
            else {
                if(determine > 50){
                    enemy.texture = PIXI.loader.resources["images/RamielAttack.png"].texture;
                    let b = new Projectile(enemy.x - 200,enemy.y + 80,1200, PIXI.loader.resources["images/RamielShot.png"].texture);
                    projectiles.push(b);
                    stage1.addChild(b);
                    shootSound.play();
                    shootSound.volume(0.2);
                }
                else{
                    enemy.texture = PIXI.loader.resources["images/Ramiel.png"].texture;
                    enemy.vx = -.5;
                }
            }
        }
        
        //third enemy
        else if(enemy.type == 3){
            
            //default texture
            enemy.texture = PIXI.loader.resources["images/ZeruelStand.png"].texture;
            
            //attack if close at interval
            if((enemy.x - player.x) < 300){
                enemy.texture = PIXI.loader.resources["images/ZeruelAttack.png"].texture;
            }
            else {
                if(determine > 66){
                    enemy.vx = -8;
                    enemy.vy = -20;
                    enemyJump = true;
                    jumpSound.play();
                    enemy.texture = PIXI.loader.resources["images/ZeruelJump.png"].texture;
                }
                else if(determine > 40){
                    enemy.texture = PIXI.loader.resources["images/ZeruelFire.png"].texture;
                    let b = new Projectile(enemy.x - 200,enemy.y + 80,1200, PIXI.loader.resources["images/ZeruelShot.png"].texture);
                    projectiles.push(b);
                    stage1.addChild(b);
                    shootSound.play();
                    shootSound.volume(0.2);
                }
                else{
                    enemy.vx = -2; 
                }
            }
        }//end type 3
        
    }//end determination
    
    //add velocity
    enemy.x += enemy.vx;
    enemy.y += enemy.vy;
}//end function

//check for collisions with enemies
function collisionCheck(enemy){
    if(rectsIntersect(player,enemy)){
        if(enemy.type == "projectile"){
            hurt = true;
            decreaseLifeBy(7);
            countdown = 30;
            enemy.x = 100000;
            enemy.y = 100000;
            attacking = false;
            hitSound.play();
            slideSound.play();
        }
        if(hurt == false && attacking == false){
            hurt = true;
            decreaseLifeBy(10);
            countdown = 30;
            hitSound.play();
            if(enemy.type != 2){
                enemy.enemyHurt = true;
            }
            enemy.countdown = 20;
            slideSound.play();
        }
        if(attacking){
            if(enemy.enemyHurt == false){
                hitSound.play();
                multCountdown = 40;
                mult++;
                decreaseELifeBy(enemy,10);
                enemy.enemyHurt = true;
                enemy.countdown = 20;
                increaseScoreBy(10 * mult);
                slideSound.play();
            }
        }
        
    }
}

//check if enemy is hurt, make it fall back if so
function enemyIsHurt(e,dt){
    if(e.enemyHurt == true){
        e.countdown--;
        let amt = 6 * dt;
    
        let newX = lerp(e.x, e.x + 100, amt);

        let w2 = e.width/2;
        
        e.x = clamp(newX, 0+w2, app.renderer.width-w2);
    
        if(e.countdown == 0){
            e.enemyHurt = false;
        }
    }
}

//check multiplier
function checkMult(){
    if (multCountdown > 0){
        multCountdown--;
    }
    if(multCountdown == 0){
        mult = 0;
    }
}

//Level/Scene Stuff
//create labels and buttons for interface
function createLabelsAndButtons(){
    
    let buttonStyle = new PIXI.TextStyle({
        fill: 0xFCFDFF,
        fontSize: 48,
        fontFamily:"Verdana Serif"
    });
    
    //set up startscene
    //start game button
    let startButton = new PIXI.Text("Launch");
    startButton.style = buttonStyle;
    startButton.x = 765;
    startButton.y = 450;
    startButton.interactive = true;
    startButton.buttonMode = true;
    startButton.on("pointerup", startGame);
    startButton.on('pointerover', e=>e.target.alpha = 0.7);
    startButton.on('pointerout',e=>startButton.alpha = 1.0);
    startScene.addChild(startButton);    
    
    //check for high score, label - if not greater than 0, label it zero - avoids "null"
    if(!(localStorage.getItem("kmf-7094-highScore") > "0")){
        startScore = new PIXI.Text(`High Score: 0`);
    }
    else{ //otherwise show the highscore
        startScore = new PIXI.Text(`High Score: ${localStorage.getItem("kmf-7094-highScore")}`);
    }
    startScore.style = buttonStyle;
    startScore.x = 540;
    startScore.y = 50;
    startScene.addChild(startScore);
    
    //set up gamescene text
    let textStyle = new PIXI.TextStyle({
        fill: 0xFFFFFF,
        fontSize: 22,
        fontFamily: "Verdana Serif",
        stroke:  0x000000,
        strokeThickness: 8
    });
    
    //score label
    scoreLabel = new PIXI.Text();
    scoreLabel.style = textStyle;
    scoreLabel.x = 5;
    scoreLabel.y = 5;
    stage1.addChild(scoreLabel);
    increaseScoreBy(0);
    
    //armor/life label
    lifeLabel = new PIXI.Text();
    lifeLabel.style = textStyle;
    lifeLabel.x = 5;
    lifeLabel.y = 30;
    stage1.addChild(lifeLabel);
    decreaseLifeBy(0);    
    
    //enemy life label
    lifeLabelE = new PIXI.Text();
    lifeLabelE.style = textStyle;
    lifeLabelE.x = 820;
    lifeLabelE.y = 30;
    stage1.addChild(lifeLabelE);    
    
    //combo counter
    comboLabel = new PIXI.Text();
    comboLabel.style = textStyle;
    comboLabel.x = 820;
    comboLabel.y = 5;
    stage1.addChild(comboLabel);
    comboLabel.text = `Combo ${mult}!`;    
    
    //show how far player is to end of scroller
    scrollLabel = new PIXI.Text();
    scrollLabel.style = textStyle;
    scrollLabel.x = 765;
    scrollLabel.y = -100;
    stage2.addChild(scrollLabel);
    scrollLabel.text = `${scrollTimePassed}m/1800m`;
    
    //game over scene 
    //Restart button
    menuButton = new PIXI.Text("Return");
    menuButton.style = buttonStyle;
    menuButton.x = 765;
    menuButton.y = 415;
    menuButton.interactive = true;
    menuButton.buttonMode = true;
    menuButton.on("pointerup", reset);
    menuButton.on('pointerover', e=>e.target.alpha = 0.7);
    menuButton.on('pointerout',e=>menuButton.alpha = 1.0);
    gameOverScene.addChild(menuButton);
    
}

//reset scene
function reset(){
    location.reload(); //reload page - easy way
}

//raise levelNum and adjust scene accordingly
function nextLevel(){
    
    //increase levelNum to decide what level to set up next
    levelNum++;
    player.texture = PIXI.loader.resources["images/PlayerStand.png"].texture; //reset player texture
    
    //next level
    if(levelNum == 2){
        deathSound.play();
        deathSound.volume(.3);
        cardCountdown = 180;
        player.x = 10;
        player.y= 540;
        enemy1.isAlive = false;
        enemy1.visible = false;
        enemy2.isAlive = true;
        enemy2.visible = true;
        decreaseELifeBy(enemy2,0);
    }
    
    //level3
    if(levelNum == 3){
        deathSound.play();
        deathSound.volume(.3);
        ramielSound.stop();
        cardCountdown = 180;
        enemy2.isAlive = false;
        enemy2.visible = false;
        enemy3.visible = true;
        enemy3.isAlive = true;
        player.x = 10;
        player.y = 540;
        decreaseELifeBy(enemy3,0);
    }
    
    //sidescroller
    if(levelNum == 4){
        deathSound.play();
        deathSound.volume(.3);
        cardCountdown = 180;
        enemy3.visible = false;
        enemy3.isAlive = false;
        stage2.visible = true;
        player.x = 150;
        lifeLabelE.x = 2000;
        comboLabel.x = 2000;
        player.y = 540;
        sideScroll = true;
    }
    
    //ending
    if(levelNum == 5){
        app.ticker.remove(walkAnim);
        cardCountdown = 150;
        stage2.visible = false;
        sideScroll = false;
        //check high score - resource: https://stackoverflow.com/questions/29370017/adding-a-high-score-to-local-storage
        if(highScore != null){
            if(score > localStorage.getItem("kmf-7094-highScore")){
                localStorage.setItem("kmf-7094-highScore", score);
            }
        }
        else{
            localStorage.setItem("kmf-7094-highScore",score);
        }
    }
}

//setup scenes
function setup() {
    
    stage = app.stage;
    
    stage.addChild(background);
    background.anchor.set(0.5);
    background.x = app.renderer.width/2;
    background.y = app.renderer.height/2;
    
	// Create the `start` scene
	startScene = new PIXI.Container();
    startScene.visible = true;
    stage.addChild(startScene);
    
	// Create the first `game` scene
    stage1 = new PIXI.Container();
    stage1.visible = false;
    stage.addChild(stage1);
    
    // Create sidescrolling segment
    stage2 = new PIXI.Container();
    stage2.visible = false;
    stage.addChild(stage2);
    
	// Create the `gameOver` scene and make it invisible
	gameOverScene = new PIXI.Container();
    gameOverScene.visible = false;
    stage.addChild(gameOverScene);
    
    // buttons and text
    createLabelsAndButtons();
    
    // Load Sounds
	shootSound = new Howl({
        src: ['sounds/Fire.mp3']
    });
    
    hitSound = new Howl({
        src:['sounds/Hit.mp3']
    });
    
    deathSound = new Howl({
        src:['sounds/Cross.mp3']
    });
    
	buttonSound = new Howl({
        src: ['sounds/Button.mp3']
    });
    
    jumpSound = new Howl({
        src:['sounds/Jump.mp3']
    });
    
    musicSound = new Howl({
        src:['sounds/Music.mp3'],
        loop:true
    });
	ramielSound = new Howl({
        src: ['sounds/Ramiel.mp3'],
        loop:true
    });
    
    slideSound = new Howl({
        src:['sounds/Slide.mp3']
    });
    
    walkSound = new Howl({
        src:['sounds/Walk.mp3']
    });
    
    //load ending anim
    finaleAnim = loadSpriteSheet();
    
    // game loop
    app.ticker.add(gameLoop);
    
}

//"infinite" scroller
function scroller(){
    
    let b;
    scrollTimePassed++;
    
    //scroll back
    for(let s of scrollers){
        s.visible = true;
        s.x -= 8;
        if(s.x < -959){
            s.x = 1920;
        }
    }
    
    //update scroll label/progress shown
    scrollLabel.text = `${scrollTimePassed}m/1800m`;
    if(scrollTimePassed > 1800){
        nextLevel();
    }
    
    enemyMoveCountdown--;
    determine = 0;
    determine = Math.floor(Math.random() * 100) + 1;
    
    //send out random rubble projectile
    if(determine > 95 && enemyMoveCountdown < 1){
        if(determine > 97){
            b = new Projectile(1000,408,1000, PIXI.loader.resources["images/Obstacle.png"].texture);
        }
        else{
            b = new Projectile(1000,360,1000, PIXI.loader.resources["images/Obstacle2.png"].texture);
        }
        projectiles.push(b);
        stage1.addChild(b);
        enemyMoveCountdown = 55;
    }
    
}

//check for movement, attacks, and collisions, etc.
function gameLoop(){

    //check background with first two screens, apply appropriate one
    if(startScene.visible){
        levelNum = 0;
        background.texture = PIXI.loader.resources["images/StartCard.png"].texture;
    }
    
    //handle intro and title cards
    titleCards();
    
    //update combo label
    comboLabel.text = `Combo ${mult}!`;
    
    //if paused, don't apply game loop
    if(paused) return;
    
	//Calculate "delta time"
	let dt = 1/app.ticker.FPS;
    if(dt > 1/12) dt = 1/12;
	
    //check for movement
    move();
    
    //check if off screen
    checkBounds();
    
    //check for player attacks
    if(sideScroll == false){
        attacks();
    }
    else{
        scroller();
    }
    
    //ai for enemy (depends on type too)
    for(let i of enemy){
        if(i.isAlive == true){
            enemyMove(i,dt);
        }
    }

    
    //check collisions with living enemies and projectiles
    for(let e of enemy){
        if(e.isAlive){
            collisionCheck(e);
        }
    }    
    for(let p of projectiles){
        collisionCheck(p);
        p.move(dt);
    }
    
    //check score multiplier countdown
    checkMult();
    
    //if hurt, fall back
    if(hurt == true){
        countdown--;
        let amt = 6 * dt;
    
        let newX = lerp(player.x, 10, amt);

        let w2 = player.width/2;
        
        player.x = clamp(newX, 0+w2, app.renderer.width-w2);
    
        if(countdown == 0){
            hurt = false;
            attacking = false;
            player.texture = PIXI.loader.resources["images/PlayerStand.png"].texture;
        }
    }
    
    //if enemy is hurt, move them back
    for(let f of enemy){
        if(f.isAlive){
            enemyIsHurt(f,dt);
        }
    }
    
    //add velocities to position
    player.x += player.vx;
    player.y += player.vy;
	
	//check if player is dead
	if(life <= 0){
        end();
        return;
    }
    
    //load next level is enemy is dead
    for(let g of enemy){
        if(g.life <= 0 && g.isAlive){
            nextLevel();
        }
    }
	
}

//end game if you die
function end(){
    
    //only do death stuff once --------------------
    deathSingle++;
    if(deathSingle == 1){
        deathSound.play();
        deathSound.volume(.3);
        //check high score - resource: https://stackoverflow.com/questions/29370017/adding-a-high-score-to-local-storage
        if(highScore != null){
            if(score > localStorage.getItem("kmf-7094-highScore")){
                localStorage.setItem("kmf-7094-highScore", score);
            }
        }
        else{
            localStorage.setItem("kmf-7094-highScore",score);
        }

    }
    //-----------------------------------------------
    
    gameOverScene.visible = true;
    background.texture = PIXI.loader.resources["images/FailureCard.png"].texture;
    stage1.visible = false;
    stage2.visible = false;
    player.y = 0;
    startScene.visible = false;
    
}